var mobile_appRoutes = [
	{
		"path": "/services/userapi",
		"manual": true,
		"destination": "userapi"
	},
	{
		"path": "/TGN_MANT",
		"destination": "TGN_MANT"
	}
];

